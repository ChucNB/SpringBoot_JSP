CREATE TRIGGER  tg_updateProduct ON HoaDonChiTiet
FOR UPDATE
AS
SELECT * FROM inserted
go

